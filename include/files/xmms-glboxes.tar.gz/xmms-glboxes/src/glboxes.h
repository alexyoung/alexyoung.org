#include <glib.h>
#include <gtk/gtk.h>
#include <GL/gl.h>
#include <GL/glx.h>
#include <X11/Xlib.h>
#include <X11/extensions/xf86vmode.h>
#include "config.h"

#define NUMBER_OF_OBJECTS 1
#define DEFAULT_SPEED 65
#define MAX_NUMBER_OF_CUBES 8
#define WIDTH 640
#define HEIGHT 480
#define COLOUR_FREQ 1800
#define INIT_SIZE 1.2

typedef struct
{
    int window;
    gboolean window_open;
    gboolean plugin_enabled;
    GLuint glboxes_texture[1];
} state_t;

typedef struct
{
    int r, g, b;
    float x, y, z;
    float zoom;
    float spin_speed;
    int timer;
} cube_t;

typedef struct 
{
    int cubes;
    int col_speed;
    int width, height;
    char *texture_filename;
    float zoom;
    int spin_speed;
} option_t;

typedef struct 
{
    unsigned long width;
    unsigned long height;
    char *data;
} image_t;
