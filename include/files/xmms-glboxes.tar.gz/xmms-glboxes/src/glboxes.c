#include "glboxes.h"
#include "glconfig.c"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "xmms/plugin.h"
#include <xmms/util.h>

#include <gtk/gtk.h>
#include <GL/glut.h>

#include <X11/extensions/xf86vmode.h>
#include <X11/Xlib.h>

#include <pthread.h>
#ifdef HAVE_SCHED_SETSCHEDULER
#include <sched.h>
#endif


/* OpenGL globals */
cube_t cubes[MAX_NUMBER_OF_CUBES];
option_t options;
image_t *image;
state_t state;

/* PThread globals */
static pthread_t p_draw_thread;

void GLBoxes_Init(void);
static void GLBoxes_Start(void);
static void GLBoxes_Stop(void);
void GLBoxes_Cleanup(void);
static void GLBoxes_Render_Freq(gint16 data[][256]);


VisPlugin XMMS_GLBOXES_PLUGIN = 
{
    NULL,
    NULL,
    0,
    NULL,
    0,
    1,
    GLBoxes_Init,
    GLBoxes_Cleanup,
    NULL,
    GLBoxes_Configure,
    NULL,
    GLBoxes_Start,
    GLBoxes_Stop,
    NULL,
    GLBoxes_Render_Freq
};


VisPlugin * get_vplugin_info(void)
{
    XMMS_GLBOXES_PLUGIN.description = g_strdup_printf("GLBoxes 0.1");
    return &XMMS_GLBOXES_PLUGIN;
} /* get_vplugin_info */


int Image_Load(char *filename, image_t *image)
{   
    FILE *file;
    unsigned long size;
    unsigned long i;
    char temp;

    if ((file = fopen(filename, "rb")) == NULL)
    {   
        printf("File Not Found: %s\n", filename);
        return FALSE;
    }

    image->width = 256;
    image->height = 256;
    size = image->width * image->height * 3;
    fseek(file, 24, SEEK_CUR);

    image->data = (char *) malloc(size);

    if (image->data == NULL)
    {   
        printf("Could not allocate space for texture.\n");
        return FALSE;
    }

    if ((i = fread(image->data, size, 1, file)) != 1)
    {   
        printf("Error reading image data from %s.\n", filename);
        return FALSE;
    }

    for (i = 0; i < size; i += 3)
    {   
        temp = image->data[i];
        image->data[i] = image->data[i + 2];
        image->data[i + 2] = temp;
    }

    return TRUE;
} /* Image_Load */


GLvoid Load_GL_Textures(GLvoid)
{   
    if (image == NULL)
    {
        printf("Error allocating space for image");
        exit(0);
    }

    if (!Image_Load(options.texture_filename, image))
    {
        GLBoxes_Cleanup();
    }
 
    glGenTextures(1, &state.glboxes_texture[0]);
    glBindTexture(GL_TEXTURE_2D, state.glboxes_texture[0]);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, image->width, image->height, 0, GL_RGB, GL_UNSIGNED_BYTE, image->data);
} /* Load_GL_Textures */


void Draw_Cube(void)
{   
    glBegin(GL_QUADS);
        // Front Face
        glTexCoord2f(0.0f, 0.0f); glVertex3f (-1.0f, -1.0f,  1.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f ( 1.0f, -1.0f,  1.0f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f ( 1.0f,  1.0f,  1.0f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f (-1.0f,  1.0f,  1.0f);

        // Back Face
        glTexCoord2f(1.0f, 0.0f); glVertex3f (-1.0f, -1.0f, -1.0f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f (-1.0f,  1.0f, -1.0f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f ( 1.0f,  1.0f, -1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f ( 1.0f, -1.0f, -1.0f);

        // Top Face
        glTexCoord2f(0.0f, 1.0f); glVertex3f (-1.0f,  1.0f, -1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f (-1.0f,  1.0f,  1.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f ( 1.0f,  1.0f,  1.0f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f ( 1.0f,  1.0f, -1.0f);

        // Bottom Face
        glTexCoord2f(1.0f, 1.0f); glVertex3f (-1.0f, -1.0f, -1.0f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f ( 1.0f, -1.0f, -1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f ( 1.0f, -1.0f,  1.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f (-1.0f, -1.0f,  1.0f);

        // Right face
        glTexCoord2f(1.0f, 0.0f); glVertex3f ( 1.0f, -1.0f, -1.0f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f ( 1.0f,  1.0f, -1.0f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f ( 1.0f,  1.0f,  1.0f);
        glTexCoord2f(0.0f, 0.0f); glVertex3f ( 1.0f, -1.0f,  1.0f);

        // Left Face
        glTexCoord2f(0.0f, 0.0f); glVertex3f (-1.0f, -1.0f, -1.0f);
        glTexCoord2f(1.0f, 0.0f); glVertex3f (-1.0f, -1.0f,  1.0f);
        glTexCoord2f(1.0f, 1.0f); glVertex3f (-1.0f,  1.0f,  1.0f);
        glTexCoord2f(0.0f, 1.0f); glVertex3f (-1.0f,  1.0f, -1.0f);
    glEnd();
} /* Draw_Cube */


GLvoid Draw_GL_Scene(GLvoid)
{
    int i;

    /* plugin_enabled allows me to stop drawing if the plugin
     * has just been closed, since the main glut loop runs in
     * its own thread. window_open also tries to close the window
     * when it has been closed */
    
    if (!state.plugin_enabled)
    {
        if (state.window_open)
        {
            glutDestroyWindow(state.window);
            state.window_open = FALSE;
        }
        else
        { 
            if (!glutGetWindow())
            {
                Write_Config();
                pthread_cancel(p_draw_thread);
            }
        }
    }
    else
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glBindTexture(GL_TEXTURE_2D, state.glboxes_texture[0]);

        for (i = 0; i < options.cubes; i++)
        {
            glLoadIdentity();
            glTranslatef(0.0f, -0.0f, -8.0);

            cubes[i].zoom = options.zoom;
	    
            glScalef(cubes[i].zoom,
                     cubes[i].zoom,
                     cubes[i].zoom);

            glRotatef(cubes[i].x, 1.0f, 0.0f, 0.0f);
            glRotatef(cubes[i].y, 0.0f, 1.0f, 0.0f);
            glRotatef(cubes[i].z, 0.0f, 0.0f, 1.0f);

            cubes[i].x += cubes[i].spin_speed / options.spin_speed;
            cubes[i].y += cubes[i].spin_speed / options.spin_speed;
            cubes[i].z += cubes[i].spin_speed / options.spin_speed;

            glColor4ub(cubes[i].r, cubes[i].g, cubes[i].b, 255);
            Draw_Cube();

            cubes[i].timer++;

            if (cubes[i].timer > ((int)(options.col_speed * rand()/(RAND_MAX + 1.0)) + 300))
            {
                cubes[i].timer = 0;
                cubes[i].r = (rand() % 256);
                cubes[i].g = (rand() % 256);
                cubes[i].b = (rand() % 256);
            }
        }

        glutSwapBuffers();
    }
} /* Draw_GL_Scene */


GLvoid Init_GL(GLvoid)
{
    int i;

    glutInitDisplayMode(GLUT_DOUBLE);

    glutInitWindowSize(options.width, options.height);
    glutInitWindowPosition(0, 0);
    state.window = glutCreateWindow("GLBoxes");
    state.window_open = TRUE;

    image = (image_t *) malloc(sizeof(image_t));
    
    glutDisplayFunc(&Draw_GL_Scene);
    glutIdleFunc(&Draw_GL_Scene);
    
    Load_GL_Textures();
   
    glEnable(GL_TEXTURE_2D);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClearDepth(1.0);
    glShadeModel(GL_SMOOTH);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat)options.width/(GLfloat)options.height, 0.1f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);
    glEnable(GL_BLEND);
    
    for (i = 0; i < MAX_NUMBER_OF_CUBES; i++) 
    {
         cubes[i].r = (rand() % 256);
         cubes[i].g = (rand() % 256);
         cubes[i].b = (rand() % 256);
         cubes[i].timer = 0;
	 cubes[i].spin_speed = 1 + (rand() % 64);
         cubes[i].zoom = options.zoom * 2;
    }
} /* Init_GL */            


void * p_Draw_Thread_Func(void *arg)
{
#ifdef HAVE_SCHED_SETSCHEDULER
    if (xmms_check_realtime_priority())
    { 
        struct sched_param sparam;
        sparam.sched_priority = sched_get_priority_max(SCHED_OTHER);
        pthread_setschedparam(pthread_self(), SCHED_OTHER, &sparam);
    }
#endif
    Init_GL();
    glutMainLoop();
    pthread_exit(NULL);
} /* Draw_Thred_Func */

void GLBoxes_Init(void)
{
    options.cubes = NUMBER_OF_OBJECTS;
    options.col_speed = COLOUR_FREQ;
    options.zoom = INIT_SIZE;
    options.texture_filename = TEXTURE;
    options.width = 640;
    options.height = 480;
    options.spin_speed = DEFAULT_SPEED;
    state.plugin_enabled = FALSE;
    
    Read_Config();

    //glViewport(0, 0, options.width, options.height);
    
    state.plugin_enabled = TRUE;

    pthread_create(&p_draw_thread, NULL, p_Draw_Thread_Func, NULL);
} /* GLBoxes_Init */


static void GLBoxes_Start(void)
{
}


static void GLBoxes_Stop(void)
{
}

void GLBoxes_Cleanup(void)
{
    void *status;

    if (state.plugin_enabled)
    {
        state.plugin_enabled = FALSE;
        pthread_join(p_draw_thread, &status);

        if (status != PTHREAD_CANCELED)
        {
            printf("p_draw_thread wasn't cancelled properly\n");
        }

        free(image);
    }
} /* GLBoxes_Cleanup */

static void GLBoxes_Render_Freq(gint16 data[2][256])
{
    gint i, c, y, x = 0;
    gint xscale[] = {1, 2, 5, 10, 20, 40, 74, 137, 255};
    
    
    for (i = 0; i < options.cubes; i++) 
    {
        for (c = xscale[i], y = 0; c < xscale[i + 1]; c++)
        {
            if (data[0][c] > y)
            {
                y = data[0][c];
            }
        }

        y >>= 7;
        if (y > 0)
        {
            x = y % 255;
            cubes[i].spin_speed = x;
        }
        else
        {
            x = x * -1;
        }

        cubes[i].r += x;
        cubes[i].g += x;
        cubes[i].b += x;
    }
} /* GLBoxes_Render_Freq */
