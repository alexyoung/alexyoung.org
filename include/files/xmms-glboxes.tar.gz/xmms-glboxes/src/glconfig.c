#include <gtk/gtk.h>
#include <glib.h>
#include <stdlib.h>

#include <xmms/configfile.h>

extern option_t options;
extern image_t *image;
extern state_t state;
extern GLvoid Load_GL_Textures(GLvoid);
extern void GLBoxes_Cleanup();
extern void GLBoxes_Init();

static GtkWidget *configure_win = NULL;
static GtkWidget *vbox, *options_frame, *options_vbox;
static GtkWidget *bbox, *ok, *cancel;

static GtkObject *box_slider_range;
static GtkWidget *box_slider;
static GtkWidget *box_label;
static GtkObject *zoom_slider_range;
static GtkWidget *zoom_slider;
static GtkWidget *zoom_label;
static GtkObject *speed_slider_range;
static GtkWidget *speed_slider;
static GtkWidget *speed_label;

static GtkWidget *filew;
static GtkWidget *file_button;
static GtkWidget *file_label;
static GtkWidget *file_entry;
static GtkWidget *file_table;


void Read_Config(void)
{
    char *filename;
    ConfigFile *fp;

    filename = g_strdup_printf("%s%s", g_get_home_dir(), "/.xmms/config");

    if (!(fp = xmms_cfg_open_file(filename)))
    {
        g_print("%s not %s found.\n", __FILE__, filename);
    }
    else
    {
        xmms_cfg_read_float(fp, "GLBoxes", "zoom", &options.zoom);
        xmms_cfg_read_int(fp, "GLBoxes", "boxes", &options.cubes);
        xmms_cfg_read_string(fp, "GLBoxes", "texture", &options.texture_filename);
	xmms_cfg_read_int(fp, "GLBoxes", "speed", &options.spin_speed);
	xmms_cfg_read_int(fp, "GLBoxes", "width", &options.width);
    	xmms_cfg_read_int(fp, "GLBoxes", "height", &options.height);		
        xmms_cfg_free(fp);
    }
    g_free(filename);
} /* Read_Config */


void Write_Config(void)
{
    char *filename;
    ConfigFile *fp;

    filename = g_strconcat(g_get_home_dir(), "/.xmms/config", NULL);
    
    fp = xmms_cfg_open_file(filename);
    if (!fp)
    {
        fp = xmms_cfg_new();
    }

    xmms_cfg_write_float(fp, "GLBoxes", "zoom", options.zoom);
    xmms_cfg_write_int(fp, "GLBoxes", "boxes", options.cubes);
    xmms_cfg_write_string(fp, "GLBoxes", "texture", options.texture_filename);
    xmms_cfg_write_int(fp, "GLBoxes", "speed", options.spin_speed);
    xmms_cfg_write_int(fp, "GLBoxes", "width", options.width);
    xmms_cfg_write_int(fp, "GLBoxes", "height", options.height);
    xmms_cfg_write_file(fp, filename);
    xmms_cfg_free(fp);
    g_free(filename);
} /* Write_Config */


void File_Sel(GtkWidget *w, GtkFileSelection *fs)
{
    strcpy(options.texture_filename, gtk_file_selection_get_filename(GTK_FILE_SELECTION(fs)));
    gtk_entry_set_text(GTK_ENTRY(file_entry), options.texture_filename);
} /* File_Sel */


void Box_Slider_Scale(GtkAdjustment *adj)
{
    options.cubes = (int)adj->value;
} /* Box_Slider_Scale */


void Zoom_Slider_Scale(GtkAdjustment *adj)
{
    options.zoom = adj->value;
} /* Zoom_Slider_Scale */


void Speed_Slider_Scale(GtkAdjustment *adj)
{
    options.spin_speed = adj->value;
} /* Speed_Slider_Scale */


static void Ok_Clicked(GtkWidget *w, gpointer data)
{
    gtk_widget_destroy(configure_win);
    Write_Config();
    if (state.plugin_enabled)
    {
	GLBoxes_Cleanup();
	GLBoxes_Init();
    }
} /* Ok_Clicked */


static void Open_File_Widget(void)
{
    filew = gtk_file_selection_new("Please select a bmp");

    gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button),
                        "clicked", GTK_SIGNAL_FUNC(File_Sel), filew);
 
    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button), 
                        "clicked", GTK_SIGNAL_FUNC(gtk_widget_destroy), (gpointer)filew);

    gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filew)->cancel_button), 
                        "clicked", GTK_SIGNAL_FUNC(gtk_widget_destroy), (gpointer)filew);
     
    gtk_widget_show(filew);
} /* Open_File_Widget */


void File_Button_Clicked(GtkWidget *widget, gpointer gdata)
{
    Open_File_Widget();
} /* File_Button_Clicked */


void Cancel_Clicked(GtkWidget *widget, gpointer gdata)
{
    Read_Config();
    gtk_widget_destroy(widget);
} /* Cancel_Clicked */


void GLBoxes_Configure(void)
{
    int width, height;

    if  (configure_win)
    {
        return;
    }

    /* This prevents the width and height being overwritten by the Read_Config() function seeing 
     * as the input for these values comes from the front end and not the config window */
    width = options.width;
    height = options.height;
    Read_Config();
    options.width = width;
    options.height = height;

    configure_win = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_container_set_border_width(GTK_CONTAINER(configure_win), 10);
    gtk_window_set_title(GTK_WINDOW(configure_win),"GLBoxes Configuration");
    gtk_window_set_position(GTK_WINDOW(configure_win), GTK_WIN_POS_MOUSE);
    gtk_signal_connect(GTK_OBJECT(configure_win), "destroy", GTK_SIGNAL_FUNC(gtk_widget_destroyed), &configure_win);

    vbox = gtk_vbox_new(FALSE, 5);

    options_frame = gtk_frame_new("Options:");
    gtk_container_set_border_width(GTK_CONTAINER(options_frame), 5);

    options_vbox = gtk_vbox_new(FALSE, 5);
    gtk_container_set_border_width(GTK_CONTAINER(options_vbox), 5);

    box_slider_range = gtk_adjustment_new(options.cubes, 1, MAX_NUMBER_OF_CUBES, 0, 0, 0);
    gtk_signal_connect(GTK_OBJECT(box_slider_range), "value_changed", GTK_SIGNAL_FUNC(Box_Slider_Scale), NULL);
    box_slider = gtk_hscale_new(GTK_ADJUSTMENT(box_slider_range));
    gtk_scale_set_digits(GTK_SCALE(box_slider), 0);
    box_label = gtk_label_new("Number of boxes:");
    gtk_misc_set_alignment(GTK_MISC(box_label), 0, 0);
    gtk_box_pack_start(GTK_BOX(options_vbox), box_label, TRUE, TRUE, 0);
    gtk_widget_show(box_label);
    gtk_box_pack_start(GTK_BOX(options_vbox), box_slider, TRUE, TRUE, 0);
    gtk_widget_show(box_slider);

    zoom_slider_range = gtk_adjustment_new((gfloat)options.zoom, 0.3, 4, 0, 0, 0);
    gtk_signal_connect(GTK_OBJECT(zoom_slider_range), "value_changed", GTK_SIGNAL_FUNC(Zoom_Slider_Scale), NULL);
    zoom_slider = gtk_hscale_new(GTK_ADJUSTMENT(zoom_slider_range));
    gtk_scale_set_digits(GTK_SCALE(zoom_slider), 5);
    zoom_label = gtk_label_new("Zoom:");
    gtk_misc_set_alignment(GTK_MISC(zoom_label), 0, 0);
    gtk_box_pack_start(GTK_BOX(options_vbox), zoom_label, TRUE, TRUE, 0);
    gtk_widget_show(zoom_label);
    gtk_box_pack_start(GTK_BOX(options_vbox), zoom_slider, TRUE, TRUE, 0);
    gtk_widget_show(zoom_slider);

    speed_slider_range = gtk_adjustment_new((gint)options.spin_speed, 1, 100, 0, 0, 0);
    gtk_signal_connect(GTK_OBJECT(speed_slider_range), "value_changed", GTK_SIGNAL_FUNC(Speed_Slider_Scale), NULL);
    speed_slider = gtk_hscale_new(GTK_ADJUSTMENT(speed_slider_range));
    gtk_scale_set_digits(GTK_SCALE(speed_slider), 0);
    speed_label = gtk_label_new("Speed:");
    gtk_misc_set_alignment(GTK_MISC(speed_label), 0, 0);
    gtk_box_pack_start(GTK_BOX(options_vbox), speed_label, TRUE, TRUE, 0);
    gtk_widget_show(speed_label);
    gtk_box_pack_start(GTK_BOX(options_vbox), speed_slider, TRUE, TRUE, 0);
    gtk_widget_show(speed_slider);

    file_button = gtk_button_new_with_label("Browse");
    gtk_signal_connect(GTK_OBJECT(file_button), "clicked", GTK_SIGNAL_FUNC(File_Button_Clicked), NULL);

    file_entry = gtk_entry_new();
    gtk_entry_set_text(GTK_ENTRY(file_entry), options.texture_filename);
    file_label = gtk_label_new("Texture: ");
    file_table = gtk_table_new(3, 2, FALSE);
    gtk_table_attach(GTK_TABLE(file_table), file_label, 0, 1, 0, 1, GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
    gtk_table_attach(GTK_TABLE(file_table), file_entry, 1, 2, 0, 1, GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);
    gtk_table_attach(GTK_TABLE(file_table), file_button, 2, 3, 0, 1, GTK_EXPAND | GTK_SHRINK | GTK_FILL, GTK_EXPAND | GTK_SHRINK | GTK_FILL, 0, 0);

    gtk_container_add(GTK_CONTAINER(options_vbox), file_table);
    gtk_container_add(GTK_CONTAINER(options_frame), options_vbox);
    gtk_widget_show(options_vbox);
    gtk_widget_show(file_table);
    gtk_widget_show(file_button);
    gtk_widget_show(file_entry);
    gtk_widget_show(file_label);

    gtk_box_pack_start(GTK_BOX(vbox), options_frame, TRUE, TRUE, 0);
    gtk_widget_show(options_frame);

    bbox = gtk_hbutton_box_new();
    gtk_button_box_set_layout(GTK_BUTTON_BOX(bbox), GTK_BUTTONBOX_END);
    gtk_button_box_set_spacing(GTK_BUTTON_BOX(bbox), 5);
    gtk_box_pack_start(GTK_BOX(vbox), bbox, FALSE, FALSE, 0);

    ok = gtk_button_new_with_label("Ok");
    gtk_signal_connect(GTK_OBJECT(ok), "clicked", GTK_SIGNAL_FUNC(Ok_Clicked), NULL);
    GTK_WIDGET_SET_FLAGS(ok, GTK_CAN_DEFAULT);
    gtk_box_pack_start(GTK_BOX(bbox), ok, TRUE, TRUE, 0);
    gtk_widget_show(ok);
    cancel = gtk_button_new_with_label("Cancel");
    gtk_signal_connect_object(GTK_OBJECT(cancel), "clicked", GTK_SIGNAL_FUNC(Cancel_Clicked), GTK_OBJECT(configure_win));
    GTK_WIDGET_SET_FLAGS(cancel, GTK_CAN_DEFAULT);
    gtk_box_pack_start(GTK_BOX(bbox), cancel, TRUE, TRUE, 0);
    gtk_widget_show(cancel);
    gtk_widget_show(bbox);
        
    gtk_container_add(GTK_CONTAINER(configure_win), vbox);
    gtk_widget_show(vbox);
    gtk_widget_show(configure_win);
    gtk_widget_grab_default(ok);
} /* GLBoxes_Configure */

