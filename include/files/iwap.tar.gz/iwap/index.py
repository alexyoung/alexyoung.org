#!/usr/bin/python2.2 -O
#
# 1. Fix HTML entities - Done
# 2. Reverse the order of the messages - Done
# 3. Send messages

import cgi, string, sys

Config = {
    'web root': 'iwap',
    'username': 'alex',
    'password': 'password',
    'server': 'server',
    'directory': 'INBOX'
}

class Imap_Handler:
    class Message: # a file-like object for passing a string to rfc822.Message
        def __init__(self, text):
            self.lines = string.split(text, '\015\012')
            self.lines.reverse()
        def readline(self):
            try: return self.lines.pop() + '\n'
            except: return ''


    def __init__(self, server, user, password):
        import imaplib
        try:
            self.mbox = imaplib.IMAP4(server)
            self.mbox.login(user, password)
        except Exception, e:
            self.list.insert(END, 'IMAP login error: ', e)
            return


    def get_mailboxes(self, directory):
        self.mbox_names = []
        mboxes = self.mbox.list(directory)
        for mbox in mboxes[1]:
            mbox_data = string.split(mbox, ' ')
            self.mbox_names.append(string.replace(string.replace(mbox_data[2], '"' + directory + '.', ''), '"', ''))
        return self.mbox_names


    def get_message_list(self, directory, mbox_name):
        import rfc822 
        # Based on: http://aspn.activestate.com/ASPN/Cookbook/Python/Recipe/52299
        try:
            result, message = self.mbox.select(directory + '.' + mbox_name, 1)
            if result != 'OK':
                raise 'IMAP Error', message

            messages = []
            typ, data = self.mbox.search(None, '(ALL)')
            data = string.split(data[0])
            data.reverse()
            for message_id in data:
                headers = self.mbox.fetch(message_id, '(RFC822.SIZE BODY[HEADER.FIELDS (SUBJECT FROM)])')
                header_data = string.split(headers[1][0][0], ' ')
                size = string.replace(header_data[2], ')', '')
                message = rfc822.Message(self.Message(headers[1][0][1]), 0)
                if not len(message['subject']):
                    message['subject'] = 'No subject'
                messages.append([message_id, message.getaddr('from'), message['subject'], (float(size) / 1024)])
            return messages

        except 'IMAP Error', message:
            print message


    def get_message(self, directory, mbox_name, message_id):
        import rfc822
        try:
            result, message = self.mbox.select(directory + '.' + mbox_name, 1)
            if result != 'OK':
                raise 'IMAP Error', message

            message = self.mbox.fetch(message_id, '(BODY[TEXT])')
            # cgi.escape is used on the message to prevent stray &s breaking WML browsers.
            return cgi.escape(message[1][0][1])

        except 'IMAP Error', message:
            print message


if (__name__ == "__main__"):
    print 'Content-type: text/vnd.wap.wml'
    print """
<?xml version='1.0'?>
<!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN"
    "http://www.wapforum.org/DTD/wml_1.1.xml" >
<wml>
<card id="card1" title="IWAP">"""

    imap = Imap_Handler(Config['server'], Config['username'], Config['password'])
    url = cgi.FieldStorage()

    if (url.has_key('message_id') and url.has_key('mbox')):
        message = imap.get_message(Config['directory'], url['mbox'].value, url['message_id'].value)
        print '<p><a href="/%s/%s/">Back</a></p>' % (Config['web root'], url['mbox'].value)
        print '<p>%s</p>' % (message)
    elif (url.has_key('mbox')):
        print '<p><a href="/%s/">Back</a><br/>' % (Config['web root'])
        print '<em>Viewing: %s</em></p>' % (url['mbox'].value)
        messages = imap.get_message_list(Config['directory'], url['mbox'].value)
        for message_header in messages:
            print ('<p><em>%s</em> &lt;%s&gt;<br/>') % (message_header[1][0], message_header[1][1])
            print ('%.2fkb&nbsp;<a href="%s">%s</a><br/>') % (message_header[3], message_header[0], message_header[2])
            print '<br/></p>'
    else:
        mboxes = imap.get_mailboxes(Config['directory'])
        # I'm not sure if this is correct, is 'inbox' standard?
        print ('<p><a href="/%s/inbox/">inbox</a></p>') % (Config['web root'])
        for mbox in mboxes:
            print ('<p><a href="/%s/%s/">%s</a>') % (Config['web root'], mbox, mbox)
            print '</p>'

    print """</card>
</wml>
"""
