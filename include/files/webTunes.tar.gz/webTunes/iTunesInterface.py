__all__ = ["iTunesInterface"]

import commands 

class iTunesInterface:
    """ 
        This just executes AppleScript.  The interface could be
        extended to use the AppleScript bindings later.
    """

    def next(self):
        commands.getoutput("""osascript -e 'tell application "itunes"' -e "next track" -e "end tell\"""")

    def previous(self):
        commands.getoutput("""osascript -e 'tell application "itunes"' -e "previous track" -e "end tell\"""")

    def pause(self):
        commands.getoutput("""osascript -e 'tell application "itunes"' -e "pause" -e "end tell\"""")

    def stop(self):
        commands.getoutput("""osascript -e 'tell application "itunes"' -e "stop" -e "end tell\"""")

    def play(self):
        commands.getoutput("""osascript -e 'tell application "itunes"' -e "play" -e "end tell\"""")

    def artist(self):
        return commands.getoutput("""osascript -e 'tell application "itunes"' -e "get artist of current track" -e "end tell\"""")

    def title(self):
        return commands.getoutput("""osascript -e 'tell application "itunes"' -e "get name of current track" -e "end tell\"""")

    def position(self):
            if self.state() != 'playing':
                return '00:00'
            else:
                position = int(commands.getoutput("""osascript -e 'tell application "itunes"' -e "get player position" -e "end tell\""""))
                if position > 60:
                    return "%02d:%02d" %(position / 60, position - position / 60 * 60)
                else:
                    return "00:%02d" % position

    def state(self):
        return commands.getoutput("""osascript -e 'tell application "itunes"' -e "get player state" -e "end tell\"""")

#iTunes = iTunesInterface()
#print iTunes.artist() + ' - ' + iTunes.title()
