__all__ = ["webTunes_HTML"]

class webTunes_HTML:
    def __init__(self, itunes):
        self.itunes = itunes

    def head(self):
        return """
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd">

<html>
    <head>
        <title>webTunes</title>
        <!-- CSS2 stylesheet -->
        <style>
body
{
    font-family: verdana;
    background-color: #414A81;
}

h2
{
    padding: 0;
    margin: 0;
    margin-bottom: 10px;
    font-family: 'Lucida Grande', Geneva, Arial, Helvetica, sans-serif;
    font-size: 13px;
}

div#Display
{
    text-align: center;

    margin-left: auto;
    margin-right: auto;
    width: 350px;
    margin-bottom: 20px;
    padding: 8px;

    background-color: #D6DBBF;

    border-bottom: white 2px solid;
    border-left: black 1px solid;
    border-right: white 2px solid;
    border-top: black 2px solid;

    -moz-border-radius: .5em; 
}

div#Controls
{
    text-align: center;

    width: 500px;
    margin-right: auto;
    margin-left: auto;

    padding: 8px;

    background-color: #B9B9B9;
    border-bottom: black 2px solid;
    border-left: white 1px solid;
    border-right: black 2px solid;
    border-top: white 2px solid;

    -moz-border-radius: .5em; 
}

div#Controls ul 
{
    text-align: center;
    margin-left: 0;
    padding-left: 0;
    display: inline;
} 

div#Controls ul li 
{
    list-style: none;
    display: inline;
}

div#Controls a
{
    padding: 5px;

    color: #333;
    background-color: #EEE;
    text-decoration: none;
    font: bold 11px verdana;

    border-bottom: black 1px solid;
    border-left: white 1px solid;
    border-right: black 1px solid;
    border-top: white 1px solid;

    margin-right: 10px;
    -moz-border-radius: .5em;
}

div#Controls a:hover
{
    border-top: black 1px solid;
    border-right: white 1px solid;
    border-left: black 1px solid;
    border-bottom: white 1px solid;

    background-color: #FFC;
}

        </style>
    </head>

<body>
"""

    def footer(self):
        return """
</body>
</html>
"""

    def controls(self):
        return """
<div id="Controls">
    <h2>webTunes</h2>
    <div id="Display">
        %s
    </div>
    <ul>
        <li><a href="previous">Prev</a></li>
        <li><a href="play">Play</a></li>
        <li><a href="stop">Stop</a></li>
        <li><a href="next">Next</a></li>
    </ul>
</div>
""" % (self.now_playing())

    def now_playing(self):
        return """

%s - <strong>%s</strong> (%s)

""" % (self.itunes.artist(), self.itunes.title(), self.itunes.position())
