#!/usr/bin/python

from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
from iTunesInterface import iTunesInterface
from webTunes_HTML import webTunes_HTML

class webTunes(BaseHTTPRequestHandler):
    itunes = iTunesInterface()
    html = webTunes_HTML(itunes)

    def do_HEAD(self):
        self.send_head()

    def do_GET(self):
        self.send_head()
        self.echo(self.html.head())
        self.echo(self.view_page(self.path))
        self.echo(self.html.footer())

    def send_head(self):
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()

    def echo(self, html):
        self.wfile.write(html)

    def view_page(self, page):
        if page == '/play':
            self.itunes.play()
        elif page == '/next':
            self.itunes.next()
        elif page == '/stop':
            self.itunes.stop()
        elif page == '/previous':
            self.itunes.previous()

        return self.html.controls()

server = HTTPServer(('', 8000), webTunes)
server.serve_forever()
